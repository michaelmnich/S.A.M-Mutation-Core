package com.uj.atm.Test;

import com.uj.atm.common.IAccountC;
import com.uj.atm.common.IAtmC;
import com.uj.atm.common.ICreditCardC;
import com.uj.atm.interfaces.IAccount;
import com.uj.atm.interfaces.IAtm;
import org.junit.Assert;
import org.junit.Test;

public class TAtm {
    @Test
    public void login(){
        IAtmC atm = new IAtmC();
        boolean login = atm.CheckPinAndLogIn(new ICreditCardC(), "0000");
        Assert.assertTrue(login);
    }

    @Test
    public void pin_false(){
        IAtmC atm = new IAtmC();
        boolean pin_false = atm.CheckPinAndLogIn(new ICreditCardC(), "1111");
        Assert.assertFalse(pin_false);
    }

    @Test
    public void login_account(){
        IAtmC atm = new IAtmC();
        boolean login_account = atm.CheckPinAndLogIn(null, "2222");
        Assert.assertFalse(login_account);
    }

    @Test
    public void bank_money_30(){
        IAtmC atm = new IAtmC();
        IAccountC account = new IAccountC();
        account.DepositFunds(30);
        double bank_money = atm.AccountStatus(account);
        Assert.assertEquals(bank_money, 30, 0.01);
    }
    @Test
    public void add_exp_null(){
        IAtmC atm = new IAtmC();
        atm.ChangePinCard(null,"0000","1234","1234");
    }
    @Test
    public void add_exp_null2(){
        IAtmC atm = new IAtmC();
        atm.AccountStatus(null);
    }
    @Test
    public void add_stop(){
        IAtmC atm = new IAtmC();
        boolean stop = atm.WithdrawFunds(null, 30);
        Assert.assertFalse(stop);
    }
    @Test
    public void add_exp_nullCard(){
        IAtmC atm = new IAtmC();
        IAccountC accountRecipient = new IAccountC();
        boolean transfer = atm.Transfer(null, accountRecipient, 50);
        Assert.assertFalse(transfer);
        Assert.assertEquals(accountRecipient.AccountStatus(), 0, 0.001);
    }

    @Test
    public void add_null_to_null(){
        IAtmC atm = new IAtmC();
        ICreditCardC creditCard = new ICreditCardC();
        IAccountC account = new IAccountC();
        account.DepositFunds(230);
        creditCard.AddAccount(account);
        boolean transfer = atm.Transfer(creditCard, null, 50);
        Assert.assertFalse(transfer);
        Assert.assertEquals(account.AccountStatus(),30,0.001);
    }
}
