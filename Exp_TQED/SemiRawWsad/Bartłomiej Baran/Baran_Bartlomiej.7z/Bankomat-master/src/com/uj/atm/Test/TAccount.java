package com.uj.atm.Test;

import com.uj.atm.common.IAccountC;
import com.uj.atm.interfaces.IAccount;
import org.junit.Assert;
import org.junit.Test;

public class TAccount {
    @Test
    public void add_money(){
        IAccountC account = new IAccountC();
        account.DepositFunds(233);
        Assert.assertEquals(account.AccountStatus(),233,0.02);
    }

    @Test(expected = IllegalArgumentException.class)
    public void false_exp(){
        IAccountC account = new IAccountC();
        account.DepositFunds(-2);
    }

    @Test
    public void add_sub(){
        IAccountC account = new IAccountC();
        account.DepositFunds(2);
        account.WithdrawFunds(2);
        Assert.assertEquals(account.AccountStatus(),0,0.001);
    }

    @Test
    public void add_exp_neg(){
        IAccountC account = new IAccountC();
        account.WithdrawFunds(-1);
    }

    @Test
    public void add_exp_null(){
        IAccountC account = new IAccountC();
        account.WithdrawFunds(1);
    }
}

