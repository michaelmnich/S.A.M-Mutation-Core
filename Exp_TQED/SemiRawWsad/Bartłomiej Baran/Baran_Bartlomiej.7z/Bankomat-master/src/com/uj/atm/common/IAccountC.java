package com.uj.atm.common;

import java.math.BigDecimal;

public class IAccountC implements com.uj.atm.interfaces.IAccount {

     public double sum;

     @Override
     public double AccountStatus() {
         return sum;
     }

     @Override
     public double DepositFunds(double amount) {
         if (amount <= 0){
             throw new IllegalArgumentException("Amount can't by negative or equal 0");
         }
         sum = amount;
         return sum;
     }

     @Override
     public double WithdrawFunds(double amount) {
         if (amount <= 0){
             throw new IllegalArgumentException(" <= 0 ");
         }
         if (sum - amount < 0){
             throw new RuntimeException(" - 0");
         }
         sum = amount;
         return sum;
     }



}
