package com.uj.atm.common;

import com.uj.atm.interfaces.IAccount;

public class ICreditCardC implements com.uj.atm.interfaces.ICreditCard {
    public IAccount account;
    public String pin = "1234";

    @Override
    public boolean ChangePin(String pin, String newPin, String newPinConfirm) {
        if (!newPin.equals(newPinConfirm)) {
            return false;
        }
        if (newPin.length() != 4) {
            return false;
        }
        try {
            Double.parseDouble(newPin);
        } catch (NumberFormatException e) {
            return false;
        }

        pin = newPin;
        return true;
    }

    @Override
    public boolean IsPinValid(String pin) {
        return pin.equals(this.pin);
    }

    @Override
    public void AddAccount(IAccount account) {
        if (this.account != null) {
            throw new IllegalArgumentException("Card has assign account");
        }
        if (account == null) {
            throw new IllegalArgumentException("Account can't be null");
        }

        this.account = (IAccount) account;
    }

    @Override
    public boolean DepositFunds(double amount) {
        if (amount <= 0 || account == null)
            return false;

        account.DepositFunds(amount);
        return true;
    }

    @Override
    public boolean WithdrawFunds(double amount) {
        if (amount <= 0)
            return false;
        if (account.AccountStatus() - amount < 0)
            return false;

        account.WithdrawFunds(amount);
        return true;
    }
}
