package com.uj.atm.Test;

import com.uj.atm.common.IAccountC;
import com.uj.atm.common.IAtmC;
import com.uj.atm.common.ICreditCardC;
import com.uj.atm.interfaces.IAccount;
import com.uj.atm.interfaces.IAtm;
import org.junit.Assert;
import org.junit.Test;

public class TCreditCard {
    @Test
    public void changePin(){
        ICreditCardC creditCard = new ICreditCardC();
        boolean changePin = creditCard.ChangePin("0000", "1234", "1234");
        Assert.assertTrue(changePin);
    }

    @Test
    public void lenght(){
        ICreditCardC creditCard = new ICreditCardC();
        boolean lenght = creditCard.ChangePin("0000", "1234", "1234");
        Assert.assertFalse(lenght);
    }

    @Test
    public void pin_confirm(){
        ICreditCardC creditCard = new ICreditCardC();
        boolean pin_confirm = creditCard.ChangePin("0000", "1234", "1234");
        Assert.assertFalse(pin_confirm);
    }


    @Test
    public void pin_ok(){
        ICreditCardC creditCard = new ICreditCardC();
        boolean pin_ok = creditCard.IsPinValid("0000");
        Assert.assertTrue(pin_ok);
    }

    @Test
    public void pin_false(){
        ICreditCardC creditCard = new ICreditCardC();
        boolean pin_false = creditCard.IsPinValid("1111");
        Assert.assertFalse(pin_false);
    }


    @Test(expected = IllegalArgumentException.class)
    public void add_null(){
        ICreditCardC creditCard = new ICreditCardC();
        creditCard.AddAccount(null);
    }
    @Test
    public void add_void(){
        ICreditCardC creditCard = new ICreditCardC();
        creditCard.AddAccount(new IAccountC());
    }


}
