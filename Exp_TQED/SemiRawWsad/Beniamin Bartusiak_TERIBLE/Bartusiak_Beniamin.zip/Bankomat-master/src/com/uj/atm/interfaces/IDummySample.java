package com.uj.atm.interfaces;

public interface IDummySample {
    long NWD(long a, long b);
}
