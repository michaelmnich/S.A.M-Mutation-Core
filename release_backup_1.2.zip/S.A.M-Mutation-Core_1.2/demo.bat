echo off 

set JavaSamArgs="-javaagent:lib\idea_rt.jar" -Dfile.encoding=UTF-8 -classpath
set ArgsClasspath="Sam;lib\junit-4.12.jar;lib\hamcrest-core-1.3.jar;PitestMaster;lib\asm-5.0.4.jar;lib\asm-commons-5.0.4.jar;lib\asm-tree-5.0.4.jar;lib\xstream-1.4.8.jar;lib\xmlpull-1.1.3.1.jar;lib\xpp3_min-1.1.4c.jar;lib\spock-core-2.4-M6-groovy-4.0.jar;lib\groovy-4.0.26.jar;lib\junit-platform-engine-1.12.2.jar;lib\junit-platform-commons-1.12.2.jar;lib\apiguardian-api-1.1.2.jar;lib\hamcrest-3.0.jar;lib\geantyref-1.3.16.jar;Sam\html;lib\stringtemplate-3.2.1.jar;lib\antlr-2.7.7.jar;lib\jopt-simple-4.9.jar"

java %JavaSamArgs% %ArgsClasspath% org.pitest.mutationtest.sam.MainWorker arg_cmd "run mutation"