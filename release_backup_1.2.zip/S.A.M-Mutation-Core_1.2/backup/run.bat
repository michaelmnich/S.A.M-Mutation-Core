echo off 

set JavaSamArgs2-backup="-javaagent:C:\Program Files\JetBrains\IntelliJ IDEA 2021.1.3\lib\idea_rt.jar=58448:C:\Program Files\JetBrains\IntelliJ IDEA 2021.1.3\bin" -Dfile.encoding=UTF-8 -classpath "C:\Program Files\Java\jdk1.8.0_291\jre\lib\charsets.jar;C:\Program Files\Java\jdk1.8.0_291\jre\lib\deploy.jar;C:\Program Files\Java\jdk1.8.0_291\jre\lib\ext\access-bridge-64.jar;C:\Program Files\Java\jdk1.8.0_291\jre\lib\ext\cldrdata.jar;C:\Program Files\Java\jdk1.8.0_291\jre\lib\ext\dnsns.jar;C:\Program Files\Java\jdk1.8.0_291\jre\lib\ext\jaccess.jar;C:\Program Files\Java\jdk1.8.0_291\jre\lib\ext\jfxrt.jar;C:\Program Files\Java\jdk1.8.0_291\jre\lib\ext\localedata.jar;C:\Program Files\Java\jdk1.8.0_291\jre\lib\ext\nashorn.jar;C:\Program Files\Java\jdk1.8.0_291\jre\lib\ext\sunec.jar;C:\Program Files\Java\jdk1.8.0_291\jre\lib\ext\sunjce_provider.jar;C:\Program Files\Java\jdk1.8.0_291\jre\lib\ext\sunmscapi.jar;C:\Program Files\Java\jdk1.8.0_291\jre\lib\ext\sunpkcs11.jar;C:\Program Files\Java\jdk1.8.0_291\jre\lib\ext\zipfs.jar;C:\Program Files\Java\jdk1.8.0_291\jre\lib\javaws.jar;C:\Program Files\Java\jdk1.8.0_291\jre\lib\jce.jar;C:\Program Files\Java\jdk1.8.0_291\jre\lib\jfr.jar;C:\Program Files\Java\jdk1.8.0_291\jre\lib\jfxswt.jar;C:\Program Files\Java\jdk1.8.0_291\jre\lib\jsse.jar;C:\Program Files\Java\jdk1.8.0_291\jre\lib\management-agent.jar;C:\Program Files\Java\jdk1.8.0_291\jre\lib\plugin.jar;C:\Program Files\Java\jdk1.8.0_291\jre\lib\resources.jar;C:\Program Files\Java\jdk1.8.0_291\jre\lib\rt.jar;G:\repos\GitHub\S.A.M-Mutation-Core\SAM\pitest-master\SAM-System\target\classes;G:\repos\GitHub\S.A.M-Mutation-Core\Resources\junit-4.12.jar;G:\repos\GitHub\S.A.M-Mutation-Core\Resources\hamcrest-core-1.3.jar;G:\repos\GitHub\S.A.M-Mutation-Core\SAM\pitest-master\pitest\target\classes;C:\Users\micha\.m2\repository\org\ow2\asm\asm\5.0.4\asm-5.0.4.jar;C:\Users\micha\.m2\repository\org\ow2\asm\asm-commons\5.0.4\asm-commons-5.0.4.jar;C:\Users\micha\.m2\repository\org\ow2\asm\asm-tree\5.0.4\asm-tree-5.0.4.jar;C:\Users\micha\.m2\repository\com\thoughtworks\xstream\xstream\1.4.8\xstream-1.4.8.jar;C:\Users\micha\.m2\repository\xmlpull\xmlpull\1.1.3.1\xmlpull-1.1.3.1.jar;C:\Users\micha\.m2\repository\xpp3\xpp3_min\1.1.4c\xpp3_min-1.1.4c.jar;C:\Users\micha\.m2\repository\org\spockframework\spock-core\2.4-M6-groovy-4.0\spock-core-2.4-M6-groovy-4.0.jar;C:\Users\micha\.m2\repository\org\apache\groovy\groovy\4.0.26\groovy-4.0.26.jar;C:\Users\micha\.m2\repository\org\junit\platform\junit-platform-engine\1.12.2\junit-platform-engine-1.12.2.jar;C:\Users\micha\.m2\repository\org\opentest4j\opentest4j\1.3.0\opentest4j-1.3.0.jar;C:\Users\micha\.m2\repository\org\junit\platform\junit-platform-commons\1.12.2\junit-platform-commons-1.12.2.jar;C:\Users\micha\.m2\repository\org\apiguardian\apiguardian-api\1.1.2\apiguardian-api-1.1.2.jar;C:\Users\micha\.m2\repository\org\hamcrest\hamcrest\3.0\hamcrest-3.0.jar;C:\Users\micha\.m2\repository\io\leangen\geantyref\geantyref\1.3.16\geantyref-1.3.16.jar;G:\repos\GitHub\S.A.M-Mutation-Core\SAM\pitest-master\pitest-html-report\target\classes;C:\Users\micha\.m2\repository\org\antlr\stringtemplate\3.2.1\stringtemplate-3.2.1.jar;C:\Users\micha\.m2\repository\antlr\antlr\2.7.7\antlr-2.7.7.jar;C:\Users\micha\.m2\repository\net\sf\jopt-simple\jopt-simple\4.9\jopt-simple-4.9.jar" 

REM --G:\repos\GitHub\S.A.M-Mutation-Core\SAM\pitest-master\SAM-System\target\classes
REM --G:\repos\GitHub\S.A.M-Mutation-Core\SAM\pitest-master\pitest\target\classes
REM --G:\repos\GitHub\S.A.M-Mutation-Core\SAM\pitest-master\pitest-html-report\target\classes


REM --C:\Users\micha\.m2\repository\com\thoughtworks\xstream\xstream\1.4.8\xstream-1.4.8.jar;
REM --C:\Users\micha\.m2\repository\xmlpull\xmlpull\1.1.3.1\xmlpull-1.1.3.1.jar;
REM --C:\Users\micha\.m2\repository\xpp3\xpp3_min\1.1.4c\xpp3_min-1.1.4c.jar;

REM --C:\Users\micha\.m2\repository\org\spockframework\spock-core\2.4-M6-groovy-4.0\spock-core-2.4-M6-groovy-4.0.jar;
REM --C:\Users\micha\.m2\repository\org\apache\groovy\groovy\4.0.26\groovy-4.0.26.jar;
REM --C:\Users\micha\.m2\repository\org\junit\platform\junit-platform-engine\1.12.2\junit-platform-engine-1.12.2.jar;

REM --C:\Users\micha\.m2\repository\org\opentest4j\opentest4j\1.3.0\opentest4j-1.3.0.jar;
REM --C:\Users\micha\.m2\repository\org\junit\platform\junit-platform-commons\1.12.2\junit-platform-commons-1.12.2.jar;
REM --C:\Users\micha\.m2\repository\org\apiguardian\apiguardian-api\1.1.2\apiguardian-api-1.1.2.jar;


REM --C:\Users\micha\.m2\repository\org\hamcrest\hamcrest\3.0\hamcrest-3.0.jar;
REM --C:\Users\micha\.m2\repository\io\leangen\geantyref\geantyref\1.3.16\geantyref-1.3.16.jar;
REM --G:\repos\GitHub\S.A.M-Mutation-Core\SAM\pitest-master\pitest-html-report\target\classes;
REM --C:\Users\micha\.m2\repository\org\antlr\stringtemplate\3.2.1\stringtemplate-3.2.1.jar;

REM --C:\Users\micha\.m2\repository\antlr\antlr\2.7.7\antlr-2.7.7.jar;
REM --C:\Users\micha\.m2\repository\net\sf\jopt-simple\jopt-simple\4.9\jopt-simple-4.9.jar


set JavaSamArgs="-javaagent:lib\idea_rt.jar" -Dfile.encoding=UTF-8 -classpath
set ArgsClasspath="Sam;lib\junit-4.12.jar;lib\hamcrest-core-1.3.jar;PitestMaster;lib\asm-5.0.4.jar;lib\asm-commons-5.0.4.jar;lib\asm-tree-5.0.4.jar;lib\xstream-1.4.8.jar;lib\xmlpull-1.1.3.1.jar;lib\xpp3_min-1.1.4c.jar;lib\spock-core-2.4-M6-groovy-4.0.jar;lib\groovy-4.0.26.jar;lib\junit-platform-engine-1.12.2.jar;lib\junit-platform-commons-1.12.2.jar;lib\apiguardian-api-1.1.2.jar;lib\hamcrest-3.0.jar;lib\geantyref-1.3.16.jar;Sam\html;lib\stringtemplate-3.2.1.jar;lib\antlr-2.7.7.jar;lib\jopt-simple-4.9.jar"






java %JavaSamArgs% %ArgsClasspath% org.pitest.mutationtest.sam.MainWorker