public class Test {
    public static void main(String[] args) {
        System.out.println("Code ocen Test To jest testowy program w Javie!");
    }
}
